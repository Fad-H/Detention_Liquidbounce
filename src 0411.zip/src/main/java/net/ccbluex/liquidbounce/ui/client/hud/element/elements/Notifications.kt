package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.EaseUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11
import java.awt.Color
import kotlin.math.max

/**
 * CustomHUD Notification element
 */
@ElementInfo(name = "Notifications")
class Notifications(x: Double = 0.0, y: Double = 20.0, scale: Float = 1F,
                    side: Side = Side(Side.Horizontal.RIGHT, Side.Vertical.DOWN)) : Element(x, y, scale, side) {

    /**
     * Example notification for CustomHUD designer
     */
    private val exampleNotification = Notification("Notification", "This is an example notification.", NotifyType.INFO)

    /**
     * Draw element
     */
    override fun drawElement(): Border? {
        // bypass java.util.ConcurrentModificationException

        LiquidBounce.hud.notifications.map { it }.forEachIndexed { index, notify ->
            GL11.glPushMatrix()

            if(notify.drawNotification(index)){
                LiquidBounce.hud.notifications.remove(notify)
            }

            GL11.glPopMatrix()
        }

        if (mc.currentScreen is GuiHudDesigner) {
            if (!LiquidBounce.hud.notifications.contains(exampleNotification))
                LiquidBounce.hud.addNotification(exampleNotification)

            exampleNotification.fadeState = FadeState.STAY
            exampleNotification.displayTime = System.currentTimeMillis()
//            exampleNotification.x = exampleNotification.textLength + 8F

            return Border(-exampleNotification.width.toFloat(), exampleNotification.height.toFloat(),0F,0F)
        }

        return null
    }

}

class Notification(val title: String, val content: String, val type: NotifyType, val time: Int=1500, val animeTime: Int=500) {
    val width=100.coerceAtLeast(Fonts.fontRegular38.getStringWidth(this.title)
        .coerceAtLeast(Fonts.fontRegular38.getStringWidth(this.content)) + 20)
    val height=30
    var fadeState = FadeState.IN
    var nowY=-height
    var displayTime=System.currentTimeMillis()
    var animeXTime=System.currentTimeMillis()
    var animeYTime=System.currentTimeMillis()
    val error = ResourceLocation("liquidbounce/notification/error.png")
    val warning = ResourceLocation("liquidbounce/notification/warning.png")
    val successful = ResourceLocation("liquidbounce/notification/checkmark.png")
    val information = ResourceLocation("liquidbounce/notification/info.png")



    /**
     * Draw notification
     */
    fun drawNotification(index: Int):Boolean {
        val realY=(-(index)*height*1.1).toInt()
        val nowTime=System.currentTimeMillis()

        //Y-Axis Animation
        if(nowY!=realY){
            var pct=(nowTime-animeYTime)/animeTime.toDouble()
            if(pct>1){
                nowY=realY
                pct=1.0
            }else{
                pct=EaseUtils.easeOutExpo(pct)
            }
            GL11.glTranslated(0.0,(realY-nowY)*pct,0.0)
        }else{
            animeYTime=nowTime
        }
        GL11.glTranslated(0.0,nowY.toDouble(),0.0)

        //X-Axis Animation
        var pct=(nowTime-animeXTime)/animeTime.toDouble()
        when(fadeState){
            FadeState.IN -> {
                if(pct>1){
                    fadeState=FadeState.STAY
                    animeXTime=nowTime
                    pct=1.0
                }
                pct=EaseUtils.easeOutExpo(pct)
            }

            FadeState.STAY -> {
                pct=1.0
                if((nowTime-animeXTime)>time){
                    fadeState=FadeState.OUT
                    animeXTime=nowTime
                }
            }

            FadeState.OUT -> {
                if(pct>1){
                    fadeState=FadeState.END
                    animeXTime=nowTime
                    pct=1.0
                }
                pct=1-EaseUtils.easeInExpo(pct)
            }

            FadeState.END -> {
                return true
            }
        }
        GL11.glTranslated(width-(width*pct),0.0,0.0)
        GL11.glTranslatef(-width.toFloat(),0F,0F)

        RenderUtils.drawCircleRect(0F,0F,width.toFloat(),height.toFloat(),2f,Color(0,0,0,180).rgb,true)
        RenderUtils.drawRect(0F,height - 3F,width.toFloat(),height.toFloat(),Color(160,160,160,60).rgb)
        GL11.glEnable(GL11.GL_BLEND)
        GL11.glDisable(GL11.GL_TEXTURE_2D)
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA)
        GL11.glEnable(GL11.GL_LINE_SMOOTH)
        GL11.glDisable(GL11.GL_CULL_FACE)
        GL11.glShadeModel(7425)


        GL11.glBegin(GL11.GL_POLYGON)

        GlStateManager.color(type.renderColor.red/255f,type.renderColor.green/255f,type.renderColor.blue/255f,0.8f)
        GL11.glVertex2d(0f.toDouble(), height - 3F.toDouble())
        GL11.glVertex2d(0f.toDouble(), height.toFloat().toDouble())
        GlStateManager.color(type.renderColor.red/255f,type.renderColor.green/255f,type.renderColor.blue/255f,0f)
        GL11.glVertex2d(max(width-width*((nowTime-displayTime)/(animeTime*2F+time)),0F).toDouble(), height.toFloat().toDouble())
        GL11.glVertex2d(max(width-width*((nowTime-displayTime)/(animeTime*2F+time)),0F).toDouble(), height - 3F.toDouble())
        GL11.glEnd()

        GL11.glShadeModel(7424)
        GL11.glEnable(GL11.GL_TEXTURE_2D)
        GL11.glEnable(GL11.GL_CULL_FACE)
        GL11.glDisable(GL11.GL_BLEND)
        GL11.glDisable(GL11.GL_LINE_SMOOTH)



        if(type.renderColor == Color(0xFF2F2F)){
            Fonts.fontRegular38.drawString(title,20F,6F,Color(250,250,250,255).rgb)
            Fonts.fontRegular38.drawString(content,20F,17F,Color(180,180,180,255).rgb)
            RenderUtils.drawImage(error,2,6,16,16)
        }else if(type.renderColor == Color(0x60E092)){
            Fonts.fontRegular38.drawString(title,20F,6F,Color.WHITE.rgb)
            Fonts.fontRegular38.drawString(content,20F,17F,Color(180,180,180,255).rgb)
            RenderUtils.drawImage(successful,2,6,16,16)
        }else if(type.renderColor == Color(0xF5FD00)){
            Fonts.fontRegular38.drawString(title,20F,6F,Color(250,250,250,255).rgb)
            Fonts.fontRegular38.drawString(content,20F,17F,Color(180,180,180,255).rgb)
            RenderUtils.drawImage(warning,2,6,16,16)
        }else if(type.renderColor == Color(0x6490A7)){
            Fonts.fontRegular38.drawString(title,20F,6F,Color(250,250,250,255).rgb)
            Fonts.fontRegular38.drawString(content,20F,17F,Color(180,180,180,255).rgb)
            RenderUtils.drawImage(information,1,5,18,18)
        }
        return false
    }
}

enum class NotifyType(var renderColor: Color) {
    SUCCESS(Color(0x60E092)),
    ERROR(Color(0xFF2F2F)),
    WARNING(Color(0xF5FD00)),
    INFO(Color(0x6490A7));
}


enum class FadeState { IN, STAY, OUT, END }


