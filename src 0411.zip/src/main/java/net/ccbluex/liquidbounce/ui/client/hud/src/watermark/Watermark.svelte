<img class="watermark" src="img/watermark/lb-logo.svg" alt="watermark">

<style>
    .watermark {
        position: absolute;
        top: 15px;
        left: 15px;
        width: 165px;
    }
</style>