<script>
    import TabGui from "./tabgui/TabGui.svelte";
    import Watermark from "./watermark/Watermark.svelte";
    import ArrayList from "./arraylist/ArrayList.svelte";
    import Notifications from "./notification/Notifications.svelte";
</script>

<main>
    <ArrayList />
    <Watermark />
    <TabGui />
    <Notifications />
</main>