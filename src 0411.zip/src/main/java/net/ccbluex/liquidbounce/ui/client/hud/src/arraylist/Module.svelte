<script>
    export let name;
</script>

<div class="module">
    {name}
</div>

<style>
    .module {
        background-color: rgba(0, 0, 0, 0.68);
        color: white;
        font-size: 14px;
        border-radius: 4px;
        padding: 5px 15px 5px 8px;
        border-left: solid 4px #4677FF;
        text-align: right;
        width: max-content;
        font-weight: 500;
    }
</style>