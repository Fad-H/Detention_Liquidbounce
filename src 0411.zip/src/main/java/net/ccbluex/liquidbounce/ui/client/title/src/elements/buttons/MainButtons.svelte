<div class="buttons">
    <slot />
</div>

<style>
    .buttons {
        position: absolute;
        top: 150px;
        display: grid;
        grid-auto-rows: max-content;
        row-gap: 20px;
    }
</style>