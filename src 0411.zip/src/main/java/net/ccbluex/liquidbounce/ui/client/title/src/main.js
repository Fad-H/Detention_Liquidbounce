import Title from "./Title.svelte";

const app = new Title({
	target: document.body,
	props: {}
});

export default app;