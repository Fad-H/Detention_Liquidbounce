import Hud from "./Hud.svelte";

const app = new Hud({
	target: document.body,
	props: {

	}
});

export default app;