package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.features.module.modules.misc.BanChecker
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.GlStateManager
import org.lwjgl.opengl.GL11
import java.awt.Color


@ElementInfo(name = "PlayerInfo")
class PlayerInfo : Element() {
    var HM = 0
    var S = 0
    var M = 0
    var H = 0
    override fun drawElement(): Border {
        HM += 1;
        if (HM == 120){
            S += 1;
            HM = 0;
        }
        if (S == 60){
            M += 1
            S = 0
        }
        if (M == 60){
            H += 1
            M = 0
        }
        var BpsFloat = Math.sqrt(Math.pow(mc.thePlayer!!.posX - mc.thePlayer!!.prevPosX, 2.0) + Math.pow(mc.thePlayer!!.posZ - mc.thePlayer!!.prevPosZ, 2.0)) * 20 * mc.timer.timerSpeed
        var BpsDouble = (BpsFloat * 100 - (BpsFloat * 100)%1)/100
//        RenderUtils.drawCircleRect(0F, -9.5F, 120f, 42F, 2F, Color(0,0,0,40).rgb,true)
        RenderUtils.drawCircleRect(0F, -9.5F, 120f, -11F, 0f,Color(160,160,235,200).rgb,true)

        GL11.glPushMatrix()
        GL11.glEnable(GL11.GL_BLEND)
        GL11.glDisable(GL11.GL_TEXTURE_2D)
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA)
        GL11.glEnable(GL11.GL_LINE_SMOOTH)
        GL11.glDisable(GL11.GL_CULL_FACE)
        GL11.glShadeModel(7425)


        GL11.glBegin(GL11.GL_POLYGON)

        GlStateManager.color(0/255f,0/255f,0/255f,60/255f)
        GL11.glVertex2d(0f.toDouble(), (-10f).toDouble())
        GL11.glVertex2d(120f.toDouble(), (-10f).toDouble())
        GlStateManager.color(0/255f,0/255f,0/255f,25/255f)
        GL11.glVertex2d(120f.toDouble(),44f.toDouble())
        GL11.glVertex2d(0f.toDouble(),44f.toDouble())
        GL11.glEnd()

        GL11.glShadeModel(7424)
        GL11.glEnable(GL11.GL_TEXTURE_2D)
        GL11.glEnable(GL11.GL_CULL_FACE)
        GL11.glDisable(GL11.GL_BLEND)
        GL11.glDisable(GL11.GL_LINE_SMOOTH)
        GL11.glPopMatrix()

        Fonts.fontBold40.drawString("SessionInfo", 1f, -7f, Color(200,200,235,255).rgb,shadow = true)
        Fonts.fontRegular38.drawString("PlayTime§7:§f${M}min${S}sec", 1f, 3f, Color(255,255,255,255).rgb,shadow = true)
        Fonts.fontRegular38.drawString("Staff: ${BanChecker.STAFF_BAN_LAST_MIN} WatchDog: ${BanChecker.WATCHDOG_BAN_LAST_MIN}", 1f, 13f, Color(255,255,255,255).rgb,shadow = true)
//        Fonts.fontRegular38.drawString("X§7:§f${(mc.thePlayer!!.posX).roundToInt()} Y§7:§f${(mc.thePlayer!!.posY).roundToInt()} Z§7:§f${(mc.thePlayer!!.posZ).roundToInt()}", 1F, 13F, Color(255,255,255,255).rgb,shadow = true)
        Fonts.fontRegular38.drawString("${BpsDouble} Blocks§7/§fS", 1F, 23F, Color(255,255,255,255).rgb,shadow = true)
        Fonts.fontRegular38.drawString("FPS§7:§f${Minecraft.getDebugFPS().toString()}", 1F, 33F, Color(255,255,255,255).rgb,shadow = true)
        return Border(-1F, -12f, 121F, 51F)
    }

}