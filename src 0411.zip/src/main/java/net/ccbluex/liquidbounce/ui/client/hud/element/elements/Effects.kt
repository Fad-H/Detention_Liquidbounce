/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.AWTFontRenderer.Companion.assumeNonVolatile
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FontValue
import net.minecraft.client.resources.I18n
import net.minecraft.potion.Potion
import net.minecraft.potion.PotionEffect
import java.awt.Color

/**
 * CustomHUD effects element
 *
 * Shows a list of active potion effects
 */
@ElementInfo(name = "Effects")
class Effects(x: Double = 2.0, y: Double = 10.0, scale: Float = 1F,
              side: Side = Side(Side.Horizontal.RIGHT, Side.Vertical.DOWN)) : Element(x, y, scale, side) {

    private val effectFontValue = FontValue("EffectFont", Fonts.fontRegular40)
    private val timeFontValue = FontValue("TimeFont", Fonts.font35)
    private val shadow = BoolValue("Shadow", true)
    //创建数组
    private var Array = arrayOfNulls<PotionEffect>(20)
    private var Array1 = arrayOfNulls<PotionEffect?>(20)
    private var IntArray = arrayOf(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)

    //创建计数
    var I1 = 0

    /**
     * Draw element
     */
    override fun drawElement(): Border {
        var y = 0F
        var width = 0F


        val effectFontRenderer = effectFontValue.get()
        val timeFontRenderer = timeFontValue.get()

        assumeNonVolatile = true

        for (effect in mc.thePlayer.activePotionEffects) {
//
            Array[I1] = effect

            val potion = Potion.potionTypes[effect.potionID]
            val potion1 = Potion.potionTypes[Array[I1]!!.potionID]

            val number = when {
                effect.amplifier == 1 -> "II"
                effect.amplifier == 2 -> "III"
                effect.amplifier == 3 -> "IV"
                effect.amplifier == 4 -> "V"
                effect.amplifier == 5 -> "VI"
                effect.amplifier == 6 -> "VII"
                effect.amplifier == 7 -> "VIII"
                effect.amplifier == 8 -> "IX"
                effect.amplifier == 9 -> "X"
                effect.amplifier > 10 -> "X+"
                else -> ""
            }

            val colorRGB = if(Potion.getDurationString(effect).substring(Potion.getDurationString(effect).length - 2) != "**" && (Potion.getDurationString(effect).substring(Potion.getDurationString(effect).length - 2).toInt() < 10 && Potion.getDurationString(effect).substring(Potion.getDurationString(effect).length - 4,Potion.getDurationString(effect).length - 3).toInt() == 0)) Color(220,100,100).rgb else Color(140,140,140).rgb

            val name = "${I18n.format(potion.name)} ${number}§f"
            val tag = Potion.getDurationString(effect)
//            //判断效果是否消失/是否有新的效果
//            if(Array[I1] != Array1[I1]){
//                //效果时间
//                IntArray[I1] = Array[I1].duration
//            }
            if(Array[I1] != Array1[I1])
                IntArray[I1] = effect.duration

            val stringWidth = effectFontRenderer.getStringWidth(name).toFloat()
            val tagWidth = timeFontRenderer.getStringWidth(tag.toString()).toFloat()

            val theFinalWidth = if(stringWidth > tagWidth) stringWidth else tagWidth
            if (width < theFinalWidth)
                width = theFinalWidth

            RenderUtils.drawCircleRect(-60f, y + timeFontRenderer.FONT_HEIGHT ,0f, y - (3 + effectFontRenderer.FONT_HEIGHT)-2,2f,Color(0,0,0,100).rgb,true)
//            RenderUtils.drawCircleRect(-60f * (effect.duration.toFloat() / IntArray[I1].toFloat()), y + timeFontRenderer.FONT_HEIGHT ,0f, y - (3 + effectFontRenderer.FONT_HEIGHT)-2,2f,Color(0,0,0,80).rgb,true)
//            RenderUtils.drawCircleRect(-theFinalWidth - 2, y + timeFontRenderer.FONT_HEIGHT ,0f, y - (3 + effectFontRenderer.FONT_HEIGHT)-2,2f,Color(0,0,0,80).rgb,true)
//            timeFontRenderer.drawString(IntArray[I1]!!.toString(), -58f, y, colorRGB, shadow.get())
            timeFontRenderer.drawString(tag, -58f, y, colorRGB, shadow.get())
            y -= (timeFontRenderer.FONT_HEIGHT + 3)
            effectFontRenderer.drawString(name, -58f, y, potion.liquidColor, shadow.get())
//            effectFontRenderer.drawString(potion1.name.toString(), -180f, y, potion.liquidColor, shadow.get())
//            effectFontRenderer.drawString(name, -theFinalWidth, y, potion.liquidColor, shadow.get())
            y -= (effectFontRenderer.FONT_HEIGHT + 3)


            I1 += 1

        }
        Array1 = Array
        I1 = 0



        if (width == 0F)
            width = 40F

        if (y == 0F)
            y = -10f

        assumeNonVolatile = false

        return Border(2f, 3+effectFontRenderer.FONT_HEIGHT.toFloat(), -60F, y + effectFontRenderer.FONT_HEIGHT - 1F)

    }

}