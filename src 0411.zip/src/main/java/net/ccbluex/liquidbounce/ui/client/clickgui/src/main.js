import ClickGui from "./ClickGui.svelte";

const app = new ClickGui({
	target: document.body,
	props: {

	}
});

export default app;