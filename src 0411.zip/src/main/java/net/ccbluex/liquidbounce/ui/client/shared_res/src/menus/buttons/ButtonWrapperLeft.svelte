<div class="buttons">
    <slot />
</div>

<style>
    .buttons {
        background-color: rgba(0, 0, 0, .68);
        padding: 15px 25px;
        border-radius: 6px;
        display: flex;
        justify-content: space-between;
        width: 590px;
        position: absolute;
        bottom: 0;
        left: 0;
    }
</style>