/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */

package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.Gui
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.entity.Entity
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import net.minecraft.item.ItemArmor
import net.minecraft.item.ItemStack
import net.minecraft.item.ItemTool
import kotlin.math.max

/**
 * A target hud
 */
@ElementInfo(name = "Target")
class Target : Element() {

    private val decimalFormat = DecimalFormat("##0.00", DecimalFormatSymbols(Locale.SIMPLIFIED_CHINESE))
    private val targetValue = ListValue("Mode", arrayOf("Detention", "Liquidbounce", "Novoline", "CricleRect"), "Detention")
    private val fadeSpeed = FloatValue("FadeSpeed", 2F, 1F, 9F)
    private val textColor = ListValue("Text-Color", arrayOf("Black", "Gray", "White"), "Black")
    private val barColor = ListValue("HealthBar-Color", arrayOf("Blue", "Purple", "Cyan", "Gray", "White"), "White")

    private var easingHealth: Float = 0F
    private var lastTarget: Entity? = null
    private var lastFps: Float = 0f
    private var animationTime: Float = 0.1f
    private var isAnimation = true
    private var barWidth: Int = 0
    private var healthBarColor = Color(255,255,255,220)

    override fun drawElement(): Border {
        val modeValue = targetValue.get()
        val target = (LiquidBounce.moduleManager[KillAura::class.java] as KillAura).target
        if (target != null) {
            if (target != lastTarget || easingHealth < 0 || easingHealth > target.maxHealth ||
                abs(easingHealth - target.health) < 0.01) {
                easingHealth = target.health
            }

            val playerInfo = mc.netHandler.getPlayerInfo(target.uniqueID)

            var textColorValue: Int = Color(0,0,0,255).rgb
            val textColor1 = textColor.get()

            val novMassage = (((target.health * 10 - ((target.health * 10) % 1))/10)*5).roundToInt().toString() + "%"
            val movMassageWidth = Fonts.fontRegular38.getStringWidth(novMassage)

            val barColorValue = barColor.get()
            var damageColor = Color(220,220,220,220)
            var barRectColor = Color(180,180,180,250).rgb

            if (textColor1.equals("White", true)){
                textColorValue = Color(250,250,250,255).rgb
            }else if(textColor1.equals("Gray", true)){
                textColorValue = Color(140,140,140,255).rgb
            }else if(textColor1.equals("Black", true)){
                textColorValue = Color(0,0,0,225).rgb
            }

            if (barColorValue.equals("White", true)){
                healthBarColor = Color(255,255,255,220)
                damageColor = Color(220,220,220,220)
                barRectColor = Color(0,0,0,30).rgb
            }else if (barColorValue.equals("Gray", true)){
                healthBarColor = Color(180,180,180,220)
                damageColor = Color(140,140,140,220)
                barRectColor = Color(0,0,0,30).rgb
            }else if (barColorValue.equals("Cyan", true)){
                healthBarColor = Color(122,204,188,220)
                damageColor = Color(102,184,168,220)
                barRectColor = Color(0,0,0,30).rgb
            }else if (barColorValue.equals("Purple", true)){
                healthBarColor = Color(160,160,235,220)
                damageColor = Color(140,140,215,220)
                barRectColor = Color(0,0,0,30).rgb
            }else if (barColorValue.equals("Blue", true)){
                healthBarColor = Color(120,169,217,220)
                damageColor = Color(100,159,237,220)
                barRectColor = Color(0,0,0,30).rgb
            }

            if(!isAnimation){
                if(modeValue.equals("Detention", true)){
                    barWidth = if ((target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > 60 || target.health > 20){
                        if ((target.health / target.maxHealth) * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)) (target.health / target.maxHealth).roundToInt() * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) else (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)
                    }else{
                        60
                    }
                    RenderUtils.drawBorderedRect(-35.5F, -1F, barWidth + 3.5f, 2f, 0.5F, Color(255,255,255,0).rgb, healthBarColor.rgb)
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, 34.5F, 1.5F, Color(20,20,20,20).rgb, Color(0,0,0,200).rgb)
                    RenderUtils.drawBorderedRect(-35.5F, 0.5F, barWidth + 3.5f, 33.5F, 0.5F, Color(255,255,255,220).rgb, Color(0,0,0,0).rgb)

                        // Health bar
                    RenderUtils.drawBorderedRect(-1F, 18F, barWidth + 1f, 28F,0.5f,Color(0,0,0,255).rgb,barRectColor)
                    RenderUtils.drawRect(0F, 19F, (target.health / target.maxHealth) * (barWidth + 0f), 27F,healthBarColor)
                        // Damage animation
                    if (easingHealth > target.health) {
                        RenderUtils.drawRect(0f, 19F, (easingHealth / target.maxHealth) * (barWidth + 0f), 27F, damageColor.rgb)
                    }
                    easingHealth += ((target.health - easingHealth) / 2.0F.pow(10.0F - fadeSpeed.get())) * RenderUtils.deltaTime
                        // Draw info

                    target.name?.let {Fonts.fontRegular38.drawString(it, 0f, 8f, Color(255,255,255,255).rgb,shadow = true)}
                    Fonts.fontRegular38.drawString(novMassage,
                        barWidth /2 - movMassageWidth / 2 + 0f, 20f, textColorValue,shadow = true)
                    if (playerInfo != null) {
                        val locationSkin = playerInfo.locationSkin
                        drawHead(locationSkin, -34, 2,30,30)
                    }
                }else if(modeValue.equals("Liquidbounce", true)){
                    if (target != lastTarget || easingHealth < 0 || easingHealth > target.maxHealth ||
                        abs(easingHealth - target.health) < 0.01) {
                        easingHealth = target.health
                    }

                    barWidth = (38 + Fonts.font40.getStringWidth(target.name))
                        .coerceAtLeast(118)

                    // Draw rect box
                    RenderUtils.drawBorderedRect(0F, 0F, barWidth.toFloat(), 36F, 3F, Color.BLACK.rgb, Color.BLACK.rgb)

                    // Damage animation
                    if (easingHealth > target.health)
                        RenderUtils.drawRect(0F, 34F, (easingHealth / target.maxHealth) * barWidth.toFloat(),
                            36F, Color(252, 185, 65).rgb)

                    // Health bar
                    RenderUtils.drawRect(0F, 34F, (target.health / target.maxHealth) * barWidth.toFloat(),
                        36F, Color(252, 96, 66).rgb)

                    // Heal animation
                    if (easingHealth < target.health)
                        RenderUtils.drawRect((easingHealth / target.maxHealth) * barWidth.toFloat(), 34F,
                            (target.health / target.maxHealth) * barWidth.toFloat(), 36F, Color(44, 201, 144).rgb)

                    easingHealth += ((target.health - easingHealth) / 2.0F.pow(10.0F - fadeSpeed.get())) * RenderUtils.deltaTime

                    Fonts.font40.drawString(target.name, 36, 3, 0xffffff)
                    Fonts.font35.drawString("Distance: ${decimalFormat.format(mc.thePlayer.getDistanceToEntityBox(target))}", 36, 15, 0xffffff)

                    // Draw info
                    if (playerInfo != null) {
                        Fonts.font35.drawString(
                            "Ping: ${playerInfo.responseTime.coerceAtLeast(0)}",
                            36, 24, 0xffffff
                        )

                        // Draw head
                        val locationSkin = playerInfo.locationSkin
                        drawHead(locationSkin,0,0, 30, 30)
                    }
                }else if (modeValue.equals("Novoline", true)) {
                    barWidth = if ((target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > 40 || target.health > 20){
                        if ((target.health / target.maxHealth) * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)) (target.health / target.maxHealth).roundToInt() * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) else (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)
                    }else{
                        40
                    }
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, 34.5F, 0.5F, Color(0,0,0,220).rgb, Color(30,30,30,250).rgb)

                    // Health bar
                    RenderUtils.drawBorderedRect(-1F, 18F, barWidth + 1f, 28F,0.5f,Color(0,0,0,100).rgb,Color(0,0,0,60).rgb)

                    GL11.glPushMatrix()
                    GL11.glEnable(GL11.GL_BLEND)
                    GL11.glDisable(GL11.GL_TEXTURE_2D)
                    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA)
                    GL11.glEnable(GL11.GL_LINE_SMOOTH)
                    GL11.glDisable(GL11.GL_CULL_FACE)
                    GL11.glShadeModel(7425)


                    GL11.glBegin(GL11.GL_POLYGON)

                    GlStateManager.color(healthBarColor.red/255f,healthBarColor.green/255f,healthBarColor.blue/255f,220f/255f )
                    GL11.glVertex2d(0f.toDouble(), 27f.toDouble())
                    GL11.glVertex2d(0f.toDouble(), 19f.toDouble())
                    GlStateManager.color(damageColor.red/255f,damageColor.green/255f,damageColor.blue/255f,220f/255f)
                    GL11.glVertex2d(max((target.health / target.maxHealth) * (barWidth + 0f),0F).toDouble(), 19f.toDouble())
                    GL11.glVertex2d(max((target.health / target.maxHealth) * (barWidth + 0f),0F).toDouble(), 27f.toDouble())
                    GL11.glEnd()

                    GL11.glShadeModel(7424)
                    GL11.glEnable(GL11.GL_TEXTURE_2D)
                    GL11.glEnable(GL11.GL_CULL_FACE)
                    GL11.glDisable(GL11.GL_BLEND)
                    GL11.glDisable(GL11.GL_LINE_SMOOTH)
                    GL11.glPopMatrix()
                    // Damage animation
                    if (easingHealth > target.health) {
                        RenderUtils.drawRect(0f, 19F, (easingHealth / target.maxHealth) * (barWidth + 0f), 27F, damageColor)
                    }
                    easingHealth += ((target.health - easingHealth) / 2.0F.pow(10.0F - fadeSpeed.get())) * RenderUtils.deltaTime
                    // Draw info

                    target.name?.let {Fonts.fontRegular38.drawString(it, 0f, 8f, Color(255,255,255,255).rgb,shadow = true)}
                    Fonts.fontRegular38.drawString(novMassage,
                        barWidth /2 - movMassageWidth / 2 + 0f, 20f, textColorValue,shadow = true)
                    if (playerInfo != null) {
                        val locationSkin = playerInfo.locationSkin
                        drawHead(locationSkin, -34, 2,30,30)
                    }
                } else if(modeValue.equals("CricleRect",ignoreCase = true)){
                    barWidth = if ((target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > 40 || target.health > 20){
                        if ((target.health / target.maxHealth) * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) > (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)) (target.health / target.maxHealth).roundToInt() * (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0) else (target.name?.let(Fonts.fontRegular38::getStringWidth) ?: 0)
                    }else{
                        40
                    }

                    RenderUtils.drawCircleRect(-36.5F, -0.5F, barWidth + 4.5f, 34.5F, 2F, Color(0,0,0,80).rgb,true)

                    // Health bar
                    if(target.health>=0.5f) {
                        RenderUtils.drawCircleRect(
                            0F,
                            20F,
                            (target.health / target.maxHealth) * (barWidth + 0f),
                            23F,
                            1f,
                            Color(20, 180, 60).rgb
                        ,true)
                        if (easingHealth > target.health) {
                            RenderUtils.drawCircleRect(
                                0F,
                                20F,
                                (target.health / target.maxHealth) * (barWidth + 0f),
                                23F,
                                1f,
                                Color(20, 180, 60).rgb
                            ,true)
                        }
                    }
                    if(target.totalArmorValue>=0.5f)
                        RenderUtils.drawCircleRect(0f,26f,(target.totalArmorValue / 20) * (barWidth + 0f),29f,1f,Color(20,100,200).rgb,true)
                    //Color(20,100,200).rgb
                    // Damage animation
                    easingHealth += ((target.health - easingHealth) / 2.0F.pow(10.0F - fadeSpeed.get())) * RenderUtils.deltaTime
                    // Draw info

                    target.name?.let {Fonts.fontRegular38.drawString(it, 0f, 8f, Color(255,255,255,255).rgb,shadow = true)}
                    if (playerInfo != null) {
                        val locationSkin = playerInfo.locationSkin
                        drawHead(locationSkin, -34, 2,30,30)
                    }
                }
            }else if(animationTime < 20){
                isAnimation = true
                animationTime += 0.1f + (80f / Minecraft.getDebugFPS().toFloat()) / 10 * if (animationTime < 15f) animationTime else 15f
                if(modeValue.equals("Detention", true)){
                    RenderUtils.drawBorderedRect(-35.5F, -1F, barWidth + 3.5f, if(animationTime/ 20f * 35f < 2f) animationTime / 20f * 35f else 2f, 0.5F, Color(255,255,255,0).rgb, healthBarColor.rgb)
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, if(animationTime/ 20f * 35f < 34.5f) animationTime / 20f * 35f else 34.5f, 1.5F, Color(20,20,20,animationTime.roundToInt()).rgb, Color(0,0,0,(animationTime*10).roundToInt()).rgb)
                    RenderUtils.drawBorderedRect(-35.5F, 0.5F, barWidth + 3.5f, if(animationTime/ 20f * 35f < 33.5f && animationTime/ 20f * 35f > 1.5f) animationTime/ 20f * 35f else if(animationTime/ 20f * 35f > 33.5f) 33.5f else 0.5f, 0.5F, Color(255,255,255,(animationTime*11).roundToInt()).rgb, Color(0,0,0,0).rgb)
                }else if(modeValue.equals("LiquidBounce", true)){
                    RenderUtils.drawBorderedRect(0F, 0F, barWidth.toFloat(), animationTime / 20f * 36f, 3F, Color(0,0,0,(animationTime / 4 * 51).roundToInt()).rgb, Color(0,0,0,(animationTime / 4 * 51).roundToInt()).rgb)
                }else if(modeValue.equals("Novoline", true)){
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, if(animationTime/ 20f * 35f < 34.5f) animationTime/ 20f * 35f else 34.5f, 0.5F, Color(0,0,0,(animationTime/2*25).roundToInt()).rgb, Color(30,30,30,(animationTime/2*25).roundToInt()).rgb)
                }
            }else if(animationTime >= 20){
                isAnimation = false
            }
        }else if(animationTime > 0 && isAnimation){
            isAnimation = false
        }else if(!isAnimation){
            if(animationTime <= 0){
                isAnimation = true
                animationTime = 0f

            }else{
                animationTime -= (80f / Minecraft.getDebugFPS().toFloat()) * 10f / if (animationTime < 15f) animationTime else 15f
                if(modeValue.equals("Detention", true)){
                    RenderUtils.drawBorderedRect(-35.5F, -1F, barWidth + 3.5f, if(animationTime/ 20f * 35f < 1.5f) animationTime / 20f * 35f else 2f, 0.5F, Color(255,255,255,0).rgb, healthBarColor.rgb)
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, if(animationTime/ 20f * 35f < 34.5f) animationTime/ 20f * 35f else 34.5f, 1.5F, Color(20,20,20,animationTime.roundToInt()).rgb, Color(0,0,0,(animationTime*10).roundToInt()).rgb)
                    RenderUtils.drawBorderedRect(-35.5F, 0.5F, barWidth + 3.5f, if(animationTime/ 20f * 35f < 33.5f && animationTime/ 20f * 35f > 1.5f) animationTime/ 20f * 35f else if(animationTime/ 20f * 35f > 33.5f) 33.5f else 0.5f, 0.5F, Color(255,255,255,(animationTime*11).roundToInt()).rgb, Color(0,0,0,0).rgb)
                }else if(modeValue.equals("LiquidBounce", true)){
                    RenderUtils.drawBorderedRect(0F, 0F, barWidth.toFloat(), animationTime / 20f * 36f, 3F, Color(0,0,0,(animationTime / 4 * 51).roundToInt()).rgb, Color(0,0,0,(animationTime / 4 * 51).roundToInt()).rgb)
                }else if(modeValue.equals("Novoline", true)){
                    RenderUtils.drawBorderedRect(-36.5F, -0.5F, barWidth + 4.5f, if(animationTime/ 20f * 35f < 34.5f) animationTime/ 20f * 35f else 34.5f, 0.5F, Color(0,0,0,(animationTime/2*25).roundToInt()).rgb, Color(30,30,30,(animationTime/2*25).roundToInt()).rgb)
                }
            }
        }

        lastFps = Minecraft.getDebugFPS().toFloat()
        lastTarget = target
        return if (modeValue.equals("Detention", true)) Border(-36F, 0F, 64F, 34F) else if (modeValue.equals("Novoline", true)) Border(-36F, 0F, 40F, 34F) else Border(0F, 0F, 120F, 36F)
    }

    private fun renderArmor(player: EntityPlayer) {
        var armourStack: ItemStack?
        var renderStack = player.inventory.armorInventory
        val length = renderStack.size
        var xOffset = 36
        for (aRenderStack in renderStack) {
            armourStack = aRenderStack
        }
        if (player.heldItem != null) {
            val stock = player.heldItem.copy()
            if (stock.hasEffect() && (stock.item is ItemTool || stock.item is ItemArmor)) {
                stock.stackSize = 1
            }
            this.renderItemStack(stock, xOffset, 10)
            xOffset += 16
        }
        renderStack = player.inventory.armorInventory
        for (index in 3 downTo 0) {
            armourStack = renderStack[index]
            if (armourStack == null) continue
            this.renderItemStack(armourStack, xOffset, 10)
            xOffset += 16
        }
    }
    private fun renderItemStack(stack: ItemStack, x: Int, y: Int) {
        mc.renderItem.zLevel = -150.0f
        mc.renderItem.renderItemAndEffectIntoGUI(stack, x, y)
        mc.renderItem.renderItemOverlays(mc.fontRendererObj, stack, x, y)
    }

    private fun drawHead(skin: ResourceLocation, x: Int, y: Int, width: Int, height: Int) {
        GL11.glColor4f(1F, 1F, 1F, 1F)
        mc.textureManager.bindTexture(skin)
        Gui.drawScaledCustomSizeModalRect(x, y, 8F, 8F, 8, 8, width, height,
            64F, 64F)
    }

}