<img class="logo" src="img/logo.svg" alt="logo">

<style>
    .logo {
        position: absolute;
        top: 0;
        left: 0;
    }
</style>