package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FontValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.gui.FontRenderer
import net.minecraft.client.renderer.RenderHelper
import org.lwjgl.opengl.GL11
import java.awt.Color

/**
 * @author liulihaocai
 * InventoryHUD
 */
@ElementInfo(name = "Inventory")
class Inventory : Element(300.0,50.0,1F, Side(Side.Horizontal.RIGHT,Side.Vertical.UP)) {
    private val bgRedValue = IntegerValue("Background-Red", 0, 0, 255)
    private val bgGreenValue = IntegerValue("Background-Green", 0, 0, 255)
    private val bgBlueValue = IntegerValue("Background-Blue", 0, 0, 255)
    private val bgAlphaValue = IntegerValue("Background-Alpha", 150, 0, 255)
    private val rectRedValue = IntegerValue("Rect-Red", 100, 0, 255)
    private val rectGreenValue = IntegerValue("Rect-Green", 100, 0, 255)
    private val rectBlueValue = IntegerValue("Rect-Blue", 255, 0, 255)
    private val rectAlphaValue = IntegerValue("Rect-Alpha", 100, 0, 255)
    private val title = BoolValue("Title",true)
    private val fontValue = FontValue("Font",Fonts.fontRegular38)

    override fun drawElement(): Border {
        val backgroundColor=Color(bgRedValue.get(),bgGreenValue.get(),bgBlueValue.get(),bgAlphaValue.get()).rgb
        val rectColor = Color(rectRedValue.get(), rectGreenValue.get(), rectBlueValue.get(), rectAlphaValue.get()).rgb
        val font=fontValue.get()
        val startY=if(title.get()){-(6+font.FONT_HEIGHT)}else{0}.toFloat()

        //draw rect
        RenderUtils.drawRect(0F,0f,174F,66F,backgroundColor)
        RenderUtils.drawRect(0f, startY, 174f, 0f, rectColor)
        Fonts.font40.drawString("Inventory", 65f, -10f, Color.WHITE.rgb)

        //render item
        GL11.glPushMatrix()
        RenderHelper.enableGUIStandardItemLighting()
        renderInv(9,17,6,6,font)
        renderInv(18,26,6,24,font)
        renderInv(27,35,6,42,font)
        RenderHelper.disableStandardItemLighting()
        GL11.glPopMatrix()

        return Border(0F,startY,174F,66F)
    }

    /**
     * render single line of inventory
     * @param endSlot slot+9
     */
    private fun renderInv(slot: Int,endSlot: Int,x: Int,y: Int,font: FontRenderer){
        var xOffset=x
        for(i in slot..endSlot){
            xOffset+=18
            val stack=mc.thePlayer.inventoryContainer.getSlot(i).stack ?: continue

            mc.renderItem.renderItemAndEffectIntoGUI(stack, xOffset-18, y)
            mc.renderItem.renderItemOverlays(font, stack, xOffset-18, y)
        }
    }

}
