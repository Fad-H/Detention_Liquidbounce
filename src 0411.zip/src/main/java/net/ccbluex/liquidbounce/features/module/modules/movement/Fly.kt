package net.ccbluex.liquidbounce.features.module.modules.movement;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.PacketUtils;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

@ModuleInfo(name = "Flight", description = "Allows you to fly in survival", category = ModuleCategory.MOVEMENT)
class Fly : Module() {
    val modeValue = ListValue("FlyMode", arrayOf("Vanilla", "Hypixel"), "Vanilla")

    private var hyTicks = 0
    private var hyShouldFly = false

    @EventTarget
    fun onUpdate(Event:UpdateEvent) {
        when (modeValue.get().toLowerCase()) {
            "vanilla" -> {
                val vanillaSpeed = FloatValue("Vanilla-Speed", 2f, 0.5f, 5f)
                val vanillaVerSpeed = FloatValue("Vanilla-Vertical-Speed", 1f, 0.5f, 3f)
                mc.thePlayer.capabilities.isFlying = false

                mc.thePlayer.motionX = 0.0
                mc.thePlayer.motionY = 0.0
                mc.thePlayer.motionZ = 0.0
                if (mc.gameSettings.keyBindJump.isKeyDown) {
                    mc.thePlayer.motionY += vanillaVerSpeed.get()
                }
                if (mc.gameSettings.keyBindSneak.isKeyDown) {
                    mc.thePlayer.motionY -= vanillaVerSpeed.get()
                }

                MovementUtils.strafe(vanillaSpeed.get())
            }
            "hypixel" -> {
                hyTicks++
                if (hyTicks == 1) {
                    mc.thePlayer.motionY = 0.1
                } else if (hyTicks == 3) {
                    PacketUtils.sendPacketNoEvent(C08PacketPlayerBlockPlacement(null))
                    PacketUtils.sendPacketNoEvent(
                        C04PacketPlayerPosition(
                            mc.thePlayer.posX,
                            mc.thePlayer.posY,
                            mc.thePlayer.posZ,
                            true
                        )
                    )
                    mc.thePlayer.setPositionAndUpdate(mc.thePlayer.posX, mc.thePlayer.posY - 0.2, mc.thePlayer.posZ)
                }
                if (hyShouldFly) {
                    mc.thePlayer.motionY = 0 + Math.random() / 500
                    MovementUtils.strafe(MovementUtils.getBaseMoveSpeed().toFloat())
                } else {
                    MovementUtils.strafe(0.1f)
                }
            }
        }
    }

    @EventTarget
    fun onPacket(Event: PacketEvent) {
        when (modeValue.get().toLowerCase()) {
            "hypixel" -> {
                if (Event.packet is S08PacketPlayerPosLook) { // LagBack detect
                    hyShouldFly = true
                }
            }
        }
    }

    override fun onEnable() {
        hyTicks = 0
        hyShouldFly = false
        super.onEnable()
    }

    override val tag: String?
        get() = modeValue.get()

}
