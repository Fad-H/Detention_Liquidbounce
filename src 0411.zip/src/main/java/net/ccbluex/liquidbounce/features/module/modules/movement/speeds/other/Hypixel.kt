package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils


class Hypixel : SpeedMode("Hypxiel"){

    override fun onMotion() {
        val speed = LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed?

        if (MovementUtils.isMoving()&&!mc.gameSettings.keyBindJump.isKeyDown) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.jump()
            }
            else MovementUtils.strafe(MovementUtils.getSpeed()*1.003f)
        }
        mc.timer.timerSpeed = speed!!.customTimerValue.get()
//            mc.thePlayer.motionX = 0.0.also { mc.thePlayer.motionZ = it }
    }

    override fun onEnable() {
        super.onEnable()
    }
    override fun onDisable() {
        mc.timer.timerSpeed = 1f
        super.onDisable()
    }
    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {}

}