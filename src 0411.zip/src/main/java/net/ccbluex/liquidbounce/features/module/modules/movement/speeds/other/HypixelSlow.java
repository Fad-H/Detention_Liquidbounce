/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other;

import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MovementUtils;

public class HypixelSlow extends SpeedMode {
    private boolean legitJump = false;
    public HypixelSlow() {
        super("HypixelSlow");
    }

    @Override
    public void onMotion() {

    }

    @Override
    public void onUpdate() {
        if(!MovementUtils.isMoving()) return;
        if(mc.thePlayer.onGround&&!mc.gameSettings.keyBindJump.isKeyDown()){
            mc.thePlayer.jump();
            mc.thePlayer.speedInAir = 0.0201f;
            mc.timer.timerSpeed = 1.03f;
        }
        if(mc.thePlayer.fallDistance > 0.7 && mc.thePlayer.fallDistance < 1.3f){
            MovementUtils.strafe();
            mc.thePlayer.speedInAir = 0.02f;
            mc.timer.timerSpeed = 1.04f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {

    }
}

