/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.ui.font.GameFontRenderer;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.WorldToScreen;
import net.ccbluex.liquidbounce.utils.render.shader.FramebufferShader;
import net.ccbluex.liquidbounce.utils.render.shader.shaders.GlowShader;
import net.ccbluex.liquidbounce.utils.render.shader.shaders.OutlineShader;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Timer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import java.awt.*;

import static net.ccbluex.liquidbounce.utils.render.WorldToScreen.getMatrix;
import static org.lwjgl.opengl.GL11.*;

@ModuleInfo(name = "ESP", description = "Allows you to see targets through walls.", category = ModuleCategory.RENDER)
public class ESP extends Module {

    public static boolean renderNameTags = true;
    public final ListValue modeValue = new ListValue("Mode", new String[]{"Box", "OtherBox", "WireFrame", "2D", "Real2D", "Outline", "ShaderOutline", "ShaderGlow"}, "Box");
    public final FloatValue outlineWidth = new FloatValue("Outline-Width", 3F, 0.5F, 5F);
    public final FloatValue wireframeWidth = new FloatValue("WireFrame-Width", 2F, 0.5F, 5F);
    private final FloatValue shaderOutlineRadius = new FloatValue("ShaderOutline-Radius", 1.35F, 1F, 2F);
    private final FloatValue shaderGlowRadius = new FloatValue("ShaderGlow-Radius", 2.3F, 2F, 3F);
    private final IntegerValue colorRedValue = new IntegerValue("R", 255, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 255, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 255, 0, 255);
//    private final BoolValue rainbowValue = new BoolValue("rainbow",true);
//    private final FloatValue saturationValue = new FloatValue("Random-Saturation", 0.9f, 0f, 1f);
//    private final FloatValue brightnessValue = new FloatValue("Random-Brightness", 1f, 0f, 1f);
    private final BoolValue colorRainbow = new BoolValue("Rainbow", false);
    private final BoolValue colorTeam = new BoolValue("Team", false);

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        final String mode = modeValue.get();

        Matrix4f mvMatrix = getMatrix(GL11.GL_MODELVIEW_MATRIX);
        Matrix4f projectionMatrix = getMatrix(GL11.GL_PROJECTION_MATRIX);

        boolean real2d = mode.equalsIgnoreCase("real2d");

//        <editor-fold desc="Real2D-Setup">
        if (real2d) {
            GL11.glPushAttrib(GL11.GL_ENABLE_BIT);

            GL11.glEnable(GL11.GL_BLEND);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_DEPTH_TEST);

            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glOrtho(0, mc.displayWidth, mc.displayHeight, 0, -1.0f, 1.0);
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();

            glDisable(GL_DEPTH_TEST);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            GlStateManager.enableTexture2D();
            GlStateManager.depthMask(true);

            GL11.glLineWidth(1.0f);
        }
        //</editor-fold>

        for (final Entity entity : mc.theWorld.loadedEntityList) {
            if (entity != null && entity != mc.thePlayer && EntityUtils.isSelected(entity, false)) {
                final EntityLivingBase entityLiving = (EntityLivingBase) entity;

                Color color = getColor(entityLiving);

                switch (mode.toLowerCase()) {
                    case "box":
                    case "otherbox":
                        RenderUtils.drawEntityBox(entity, color, !mode.equalsIgnoreCase("otherbox"));
                        break;
                    case "2d": {
                        final RenderManager renderManager = mc.getRenderManager();
                        final Timer timer = mc.timer;

                        final double posX = entityLiving.lastTickPosX + (entityLiving.posX - entityLiving.lastTickPosX) * timer.renderPartialTicks - renderManager.renderPosX;
                        final double posY = entityLiving.lastTickPosY + (entityLiving.posY - entityLiving.lastTickPosY) * timer.renderPartialTicks - renderManager.renderPosY;
                        final double posZ = entityLiving.lastTickPosZ + (entityLiving.posZ - entityLiving.lastTickPosZ) * timer.renderPartialTicks - renderManager.renderPosZ;

                        RenderUtils.draw2D(entityLiving, posX, posY, posZ, color.getRGB(), Color.BLACK.getRGB());
                        break;
                    }
                    case "real2d": {
                        final RenderManager renderManager = mc.getRenderManager();
                        final Timer timer = mc.timer;

                        AxisAlignedBB bb = entityLiving.getEntityBoundingBox()
                                .offset(-entityLiving.posX, -entityLiving.posY, -entityLiving.posZ)
                                .offset(entityLiving.lastTickPosX + (entityLiving.posX - entityLiving.lastTickPosX) * timer.renderPartialTicks,
                                        entityLiving.lastTickPosY + (entityLiving.posY - entityLiving.lastTickPosY) * timer.renderPartialTicks,
                                        entityLiving.lastTickPosZ + (entityLiving.posZ - entityLiving.lastTickPosZ) * timer.renderPartialTicks)
                                .offset(-renderManager.renderPosX, -renderManager.renderPosY, -renderManager.renderPosZ);

                        double[][] boxVertices = {
                                {bb.minX, bb.minY, bb.minZ},
                                {bb.minX, bb.maxY, bb.minZ},
                                {bb.maxX, bb.maxY, bb.minZ},
                                {bb.maxX, bb.minY, bb.minZ},
                                {bb.minX, bb.minY, bb.maxZ},
                                {bb.minX, bb.maxY, bb.maxZ},
                                {bb.maxX, bb.maxY, bb.maxZ},
                                {bb.maxX, bb.minY, bb.maxZ},
                        };

                        float minX = Float.MAX_VALUE;
                        float minY = Float.MAX_VALUE;

                        float maxX = -1;
                        float maxY = -1;

                        for (double[] boxVertex : boxVertices) {
                            Vector2f screenPos = WorldToScreen.worldToScreen(new Vector3f((float) boxVertex[0], (float) boxVertex[1], (float) boxVertex[2]), mvMatrix, projectionMatrix, mc.displayWidth, mc.displayHeight);

                            if (screenPos == null) {
                                continue;
                            }

                            minX = Math.min(screenPos.x, minX);
                            minY = Math.min(screenPos.y, minY);

                            maxX = Math.max(screenPos.x, maxX);
                            maxY = Math.max(screenPos.y, maxY);
                        }

                        if ((minX > 0 || minY > 0 || maxX <= mc.displayWidth || maxY <= mc.displayWidth) && maxX > 8) {
                            int RColor;
                            RColor = 0;
                            int GColor;
                            GColor = 0;
                            int BColor;
                            BColor = 0;
                            glPushMatrix();
                            glPushAttrib(GL_ENABLE_BIT);
                            glEnable(GL_TEXTURE_2D);
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                            glEnable(GL_BLEND);
                            float health = entityLiving.getHealth();
                            Fonts.font40.drawString((int)health + "hp",minX - 7.5f - Fonts.fontRegular40.getStringWidth((int)health + "hp"),(maxY+(minY - maxY) / 20f * health),Color.WHITE.getRGB(),true);
                            glDisable(GL_TEXTURE_2D);
                            glDisable(GL_BLEND);
                            glPopAttrib();
                            GlStateManager.resetColor();
                            glPopMatrix();

                            //Black
                            glColor4f(0f, 0f, 0f,1.0f);
                            glLineWidth(2.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, minY - 1);
                            glVertex2f(minX, (maxY-minY)/3+minY + 1f);
                            glEnd();
                            glColor4f(0f, 0f, 0f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX - 1, minY);
                            glVertex2f((maxX - minX)/3+minX + 1f, minY);
                            glEnd();
                            //Write
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glLineWidth(0.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, minY);
                            glVertex2f(minX, (maxY-minY)/3+minY);
                            glEnd();
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, minY);
                            glVertex2f((maxX - minX)/3+minX, minY);
                            glEnd();
                            //black
                            glColor4f(0f/255f, 0f/255f, 0f/255f,1.0f);
                            glLineWidth(2.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX-1, minY);
                            glVertex2f(maxX-(maxX - minX)/3-1, minY);
                            glEnd();
                            glColor4f(0f/255f, 0f/255f, 0f/255f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, minY-1);
                            glVertex2f(maxX, (maxY-minY)/3+minY+1);
                            glEnd();
                            //write
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glLineWidth(0.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, minY);
                            glVertex2f(maxX-(maxX - minX)/3, minY);
                            glEnd();
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, minY);
                            glVertex2f(maxX, (maxY-minY)/3+minY);
                            glEnd();
                            //black
                            glColor4f(0f, 0f, 0f,1.0f);
                            glLineWidth(2.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX+1, maxY);
                            glVertex2f(maxX-(maxX - minX)/3-1, maxY);
                            glEnd();
                            glColor4f(0f, 0f, 0f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, maxY+1);
                            glVertex2f(maxX, maxY-(maxY-minY)/3-1);
                            glEnd();
                            //write
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glLineWidth(0.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, maxY);
                            glVertex2f(maxX-(maxX - minX)/3, maxY);
                            glEnd();
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(maxX, maxY);
                            glVertex2f(maxX, maxY-(maxY-minY)/3);
                            glEnd();
                            //black
                            glColor4f(0f/255f, 0f/255f, 0f/255f,1.0f);
                            glLineWidth(2.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX-1, maxY);
                            glVertex2f((maxX - minX)/3+minX+1, maxY);
                            glEnd();
                            glColor4f(0f/255f, 0f/255f, 0f/255f,1.0f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, maxY+1);
                            glVertex2f(minX, maxY-(maxY-minY)/3-1);
                            glEnd();
                            //write
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1.0f);
                            glLineWidth(0.5f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, maxY);
                            glVertex2f((maxX - minX)/3+minX, maxY);
                            glEnd();
                            glColor4f(colorRedValue.get()/255f,colorGreenValue.get()/255f,colorBlueValue.get()/255f,1f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX, maxY);
                            glVertex2f(minX, maxY-(maxY-minY)/3);
                            glEnd();
                            glColor4f(0f,0f,0f,0.35f);
                            glBegin(GL_QUAD_STRIP);
                            glVertex2f(maxX-1, maxY-1);
                            glVertex2f(maxX-1, minY+1);
                            glVertex2f(minX+1, maxY-1);
                            glVertex2f(minX+1, minY+1);
                            glEnd();


                            if (entityLiving.getHealth() > 19f){
                                RColor = 0;
                                GColor = 115;
                                BColor = 0;
                            }else if(entityLiving.getHealth() > 18f && entityLiving.getHealth() <= 19f){
                                RColor = 69;
                                GColor = 139;
                                BColor = 0;
                            }else if(entityLiving.getHealth() > 16f && entityLiving.getHealth() <= 18f){
                                RColor = 105;
                                GColor = 139;
                                BColor = 34;
                            }else if(entityLiving.getHealth() > 14f && entityLiving.getHealth() <= 16f){
                                RColor = 110;
                                GColor = 139;
                                BColor = 61;
                            }else if(entityLiving.getHealth() > 12f && entityLiving.getHealth() <= 14f){
                                RColor = 115;
                                GColor = 139;
                                BColor = 81;
                            }else if(entityLiving.getHealth() > 10f && entityLiving.getHealth() <= 12f){
                                RColor = 130;
                                GColor = 139;
                                BColor = 81;
                            }else if(entityLiving.getHealth() > 8f && entityLiving.getHealth() <= 10f){
                                RColor = 149;
                                GColor = 139;
                                BColor = 71;
                            }else if(entityLiving.getHealth() > 4f && entityLiving.getHealth() <= 8f){
                                RColor = 184;
                                GColor = 134;
                                BColor = 61;
                            }else if(entityLiving.getHealth() > 0f && entityLiving.getHealth() <= 4f){
                                RColor = 139;
                                GColor = 69;
                                BColor = 19;
                            }


                            if ((maxY+(minY - maxY) / 20 * entityLiving.getHealth()) < minY){
                                glColor4f(20/255f,20/255f,20/255f,100f/255f);
                                glLineWidth(2f);
                                glBegin(GL_LINE_LOOP);
                                glVertex2f(minX - 6, maxY+(minY - maxY) / 20 * entityLiving.getHealth());
                                glVertex2f(minX - 6, maxY);
                                glEnd();
                                glColor4f(20/255f,20/255f,20/255f,160f/255f);
                                glLineWidth(1f);
                                glBegin(GL_LINE_LOOP);
                                glVertex2f(minX - 7.5f, maxY+(minY - maxY) / 20 * entityLiving.getHealth() - 1);
                                glVertex2f(minX - 4.5f, maxY+(minY - maxY) / 20 * entityLiving.getHealth() - 1);
                                glVertex2f(minX - 4.5f, maxY+1);
                                glVertex2f(minX - 7.5f, maxY+1);
                                glEnd();
                            }else{
                                glColor4f(20/255f,20/255f,20/255f, 100/255f);
                                glLineWidth(2f);
                                glBegin(GL_LINE_LOOP);
                                glVertex2f(minX - 6, minY);
                                glVertex2f(minX - 6, maxY);
                                glEnd();
                                glColor4f(0/255f,0/255f,0/255f,160/255f);
                                glLineWidth(1f);
                                glBegin(GL_LINE_LOOP);
                                glVertex2f(minX - 7.5f, minY-1);
                                glVertex2f(minX - 4.5f, minY-1);
                                glVertex2f(minX - 4.5f, maxY+1);
                                glVertex2f(minX - 7.5f, maxY+1);
                                glEnd();
                            }
                            glColor4f(RColor/255f,GColor/255f,BColor/255f, 1f);
                            glLineWidth(2f);
                            glBegin(GL_LINE_LOOP);
                            glVertex2f(minX - 6, maxY);
                            glVertex2f(minX - 6, maxY+(minY - maxY) / 20 * entityLiving.getHealth());
                            glEnd();
                            for (int i = 0;i <= 10;i ++){
                                if (entityLiving.getHealth() > 20) {
                                    GL11.glColor4f(0 / 255f, 0 / 255f, 0 / 255f, 80 / 255f);
                                    GL11.glLineWidth(0.5f);
                                    GL11.glBegin(GL11.GL_LINE_LOOP);
                                    GL11.glVertex2f(minX - 7.5f, maxY + (minY - maxY) / 20 * entityLiving.getHealth() / 10 * i);
                                    GL11.glVertex2f(minX - 4.5f, maxY + (minY - maxY) / 20 * entityLiving.getHealth() / 10 * i);
                                    GL11.glEnd();
                                }else{
                                    GL11.glColor4f(0 / 255f, 0 / 255f, 0 / 255f, 80 / 255f);
                                    GL11.glLineWidth(0.5f);
                                    GL11.glBegin(GL11.GL_LINE_LOOP);
                                    GL11.glVertex2f(minX - 7.5f, minY + (maxY - minY) / 10 * i);
                                    GL11.glVertex2f(minX - 4.5f, minY + (maxY - minY) / 10 * i);
                                    GL11.glEnd();
                                }
                            }
                            for (int i=4;i>0;i--) {
                                if (entityLiving.getEquipmentInSlot(i) != null) {
                                    float posY = maxY + (minY - maxY) / 4 * (i - 1) - (maxY - minY) / 40;
                                    float maxPosY = maxY + (minY - maxY) / 4 * i + (maxY - minY) /40;
                                    glColor4f(65 / 255f, 105 / 255f, 225 / 255f, 1.0f);
                                    glLineWidth(3f);
                                    glBegin(GL_LINE_LOOP);
                                    glVertex2f(maxX + 6, posY);
                                    glVertex2f(maxX + 6, maxPosY);
                                    glEnd();
                                    glColor4f(0 / 255f, 0 / 255f, 0 / 255f, 255 / 255f);
                                    glLineWidth(1f);
                                    glBegin(GL_LINE_LOOP);
                                    glVertex2f(maxX + 8f, posY);
                                    glVertex2f(maxX + 8f, maxPosY);
                                    glVertex2f(maxX + 4f, maxPosY);
                                    glVertex2f(maxX + 4f, posY);
                                    glEnd();

                                    glPushAttrib(GL_ENABLE_BIT);
                                    glPushMatrix();
                                    glEnable(GL_TEXTURE_2D);
                                    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                                    glEnable(GL_LINE_SMOOTH);
                                    glEnable(GL_BLEND);
                                    float amror = entityLiving.getEquipmentInSlot(i).getMaxDamage()-entityLiving.getEquipmentInSlot(i).getItemDamage();
                                    Fonts.font40.drawString(String.valueOf((int)amror),maxX + 9f,posY+(maxPosY-posY)/2,Color.WHITE.getRGB(),true);
                                    glDisable(GL_BLEND);
                                    glDisable(GL_LINE_SMOOTH);
                                    glPopAttrib();
                                    GlStateManager.resetColor();
                                    glPopMatrix();
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }

        if (real2d) {
            glEnable(GL_DEPTH_TEST);

            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPopMatrix();

            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glPopMatrix();

            GL11.glPopAttrib();
        }
    }

    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        final String mode = modeValue.get();

        final FramebufferShader shader = mode.equalsIgnoreCase("shaderoutline")
                ? OutlineShader.OUTLINE_SHADER : mode.equalsIgnoreCase("shaderglow")
                ? GlowShader.GLOW_SHADER : null;

        if (shader == null) return;

        shader.startDraw(event.getPartialTicks());

        final float radius = mode.equalsIgnoreCase("shaderoutline")
                ? shaderOutlineRadius.get() : mode.equalsIgnoreCase("shaderglow")
                ? shaderGlowRadius.get() : 1F;

        shader.stopDraw(getColor(null), radius, 1F);




    }

    @Override
    public String getTag() {
        return modeValue.get();
    }

    public final Color getColor(final Entity entity) {
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;

            if (entityLivingBase.hurtTime > 0)
                return Color.RED;

            if (EntityUtils.isFriend(entityLivingBase))
                return Color.BLUE;

            if (colorTeam.get()) {
                final char[] chars = entityLivingBase.getDisplayName().getFormattedText().toCharArray();
                int color = Integer.MAX_VALUE;

                for (int i = 0; i < chars.length; i++) {
                    if (chars[i] != '§' || i + 1 >= chars.length)
                        continue;

                    final int index = GameFontRenderer.getColorIndex(chars[i + 1]);

                    if (index < 0 || index > 15)
                        continue;

                    color = ColorUtils.hexColors[index];
                    break;
                }

                return new Color(color);
            }
        }

        return colorRainbow.get() ? ColorUtils.rainbow() : new Color(colorRedValue.get(), colorGreenValue.get(), colorBlueValue.get());
    }




}
