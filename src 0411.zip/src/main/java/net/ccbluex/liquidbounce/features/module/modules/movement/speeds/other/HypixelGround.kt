package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils


class HypixelGround : SpeedMode("HypxielGround"){

    override fun onMotion() {
        //导入Speed
        val speed = LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed?

        //判断地面
        if(mc.thePlayer.onGround){
            MovementUtils.strafe(0.2999f)

        }else if(mc.gameSettings.keyBindJump.isKeyDown) { //判断是否跳跃
            MovementUtils.strafe(MovementUtils.getSpeed()*1.003f)
        }
        mc.timer.timerSpeed = speed!!.customTimerValue.get()

    }

    override fun onEnable() {
        super.onEnable()
    }
    override fun onDisable() {
        mc.timer.timerSpeed = 1f
        super.onDisable()
    }
    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {}

}