package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.entity.EntityLivingBase
import org.lwjgl.opengl.GL11

@ModuleInfo(name = "ChinaHat", category = ModuleCategory.RENDER, description = "ChinaHatOnYourHead")
class ChinaHat : Module() {

    private val isEntity = BoolValue("Entity",value = true)
    private val colorRedValue = IntegerValue("Red", 255, 0, 255)
    private val colorGreenValue = IntegerValue("Green", 255, 0, 255)
    private val colorBlueValue = IntegerValue("Blue", 255, 0, 255)
    private val colorAlphaValue = IntegerValue("Alpha", 200, 20, 255)
    private val rainbowValue = BoolValue("rainbow",value = true)
    private val saturationValue = FloatValue("Random-Saturation", 0.9f, 0f, 1f)
    private val brightnessValue = FloatValue("Random-Brightness", 1f, 0f, 1f)
    private val rotateSpeedValue = FloatValue("RotateSpeed", 2f, 0f, 5f)

    @EventTarget
    fun onRender3d(event: Render3DEvent) {
        if(mc.gameSettings.thirdPersonView != 0)
            drawHat(mc.thePlayer)
        if(isEntity.get())
            mc.theWorld.loadedEntityList.forEach {
                if(EntityUtils.isSelected(it, true)) {
                    drawHat(it as EntityLivingBase)
                }
            }

    }
    private fun drawHat(entity: EntityLivingBase) {
        GL11.glPushMatrix()
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA)
        GL11.glEnable(GL11.GL_BLEND)
        GL11.glDisable(GL11.GL_TEXTURE_2D)
        GL11.glDepthMask(false)
        GL11.glDisable(GL11.GL_CULL_FACE)
        val counter = intArrayOf(0)
        val red = ColorUtils.slowlyRainbow(System.nanoTime(),counter[0] * 100, brightnessValue.get() ,saturationValue.get()).red
        val green = ColorUtils.slowlyRainbow(System.nanoTime(),counter[0] * 100, brightnessValue.get() ,saturationValue.get()).green
        val blue = ColorUtils.slowlyRainbow(System.nanoTime(),counter[0] * 100, brightnessValue.get() ,saturationValue.get()).blue
        counter[0] = counter[0] + 1
        if(!rainbowValue.get()) {
            GL11.glColor4f(colorRedValue.get() / 255f, colorGreenValue.get() / 255f, colorBlueValue.get() / 255f, colorAlphaValue.get() / 255f)
        }else{
            GL11.glColor4f(red/255f, green/255f, blue/ 255f, colorAlphaValue.get() / 255f)
        }
        GL11.glTranslated(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * mc.timer.renderPartialTicks - mc.renderManager.renderPosX,
            entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * mc.timer.renderPartialTicks - mc.renderManager.renderPosY + entity.height + -0.01,
            entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * mc.timer.renderPartialTicks - mc.renderManager.renderPosZ)
        GL11.glRotatef((entity.ticksExisted + mc.timer.renderPartialTicks) * rotateSpeedValue.get(), 0f, 1f, 0f)

        GL11.glBegin(GL11.GL_TRIANGLE_FAN)
        GL11.glVertex3d(0.0, 0.4, 0.0)
        val PI = Math.PI
        for(i in 0..360 step 5) {
            val c = i.toDouble() * PI / 180.0
            GL11.glVertex3d(Math.cos(c) * 0.7, 0.0, Math.sin(c) * 0.7)
        }
        GL11.glVertex3d(0.0, 0.4, 0.0)
        GL11.glEnd()

        if(!rainbowValue.get()) {
            GL11.glColor4f(colorRedValue.get() / 255f, colorGreenValue.get() / 255f, colorBlueValue.get() / 255f, 1f)
        }else{
            GL11.glColor4f(red/255f, green/255f, blue/ 255f, 1f)
        }
        GL11.glLineWidth(0.5f)
        GL11.glBegin(GL11.GL_LINE_STRIP)
        for(i in 0..360 step 5){
            val c = i.toDouble() * PI /180.0
            GL11.glVertex3d(Math.cos(c) * 0.7, 0.0 , Math.sin(c) * 0.7)
        }
        GL11.glEnd()
        if(!rainbowValue.get()) {
            GL11.glColor4f(colorRedValue.get() / 255f, colorGreenValue.get() / 255f, colorBlueValue.get() / 255f, 60f/ 255f)
        }else{
            GL11.glColor4f(red/255f, green/255f, blue/ 255f, 60f/ 255f)
        }
        for(i in 1..360){
            if((i / 3.6f) - (i / 3.6f).toInt() == 0f) {
                val c = i.toDouble() * PI / 180.0
                GL11.glLineWidth(0.2f)
                GL11.glBegin(GL11.GL_LINE_STRIP)
                GL11.glVertex3d(0.0, 0.4, 0.0)
                GL11.glVertex3d(Math.cos(c) * 0.7, 0.0, Math.sin(c) * 0.7)
                GL11.glEnd()
            }
        }
        GL11.glDisable(GL11.GL_BLEND)
        GL11.glEnable(GL11.GL_TEXTURE_2D)
        GL11.glEnable(GL11.GL_CULL_FACE)
        GlStateManager.resetColor()
        GL11.glDepthMask(true)
        GL11.glDisable(GL11.GL_BLEND)
        GL11.glPopMatrix()
    }

}

