package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventState
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.misc.FallingPlayer
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.inventory.GuiInventory
import net.minecraft.init.Items
import net.minecraft.item.ItemPotion
import net.minecraft.network.play.client.*
import net.minecraft.potion.Potion
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

@ModuleInfo(name = "AutoHealth", description = "Automatically throws healing potions.", category = ModuleCategory.COMBAT)
class AutoHealth : Module() {
    private val autoHealthValue = ListValue("mode", arrayOf("Soup","Pot","All"),"Pot")

    private val healthValue = FloatValue("Health", 15F, 1F, 20F)
    private val potDelayValue = IntegerValue("PotDelay", 100, 500, 1000)
    private val soupDelayValue = IntegerValue("SoupDelay", 100, 500, 1000)

    private val openInventoryValue = BoolValue("OpenInv", false)
    private val simulateInventory = BoolValue("SimulateInventory", true)

    private val modeValue = ListValue("Pot", arrayOf("Normal", "Jump", "Port"), "Normal")
    private val bowlValue = ListValue("Soup", arrayOf("Drop", "Move", "Stay"), "Drop")

    private var potion = -1
    private val timer = MSTimer()
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (autoHealthValue.get() == "Soup" || autoHealthValue.get() == "All"){
            if (!timer.hasTimePassed(soupDelayValue.get().toLong()))
                return
            val soupInHotbar = InventoryUtils.findItem(36, 45, Items.mushroom_stew)
            if (mc.thePlayer.health <= healthValue.get() && soupInHotbar != -1) {
                mc.netHandler.addToSendQueue(C09PacketHeldItemChange(soupInHotbar - 36))
                mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(mc.thePlayer.inventoryContainer
                    .getSlot(soupInHotbar).stack))
                if (bowlValue.get().equals("Drop", true))
                    mc.netHandler.addToSendQueue(
                        C07PacketPlayerDigging(
                            C07PacketPlayerDigging.Action.DROP_ITEM,
                            BlockPos.ORIGIN, EnumFacing.DOWN)
                    )
                mc.netHandler.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
                timer.reset()
                return
            }

            val bowlInHotbar = InventoryUtils.findItem(36, 45, Items.bowl)
            if (bowlValue.get().equals("Move", true) && bowlInHotbar != -1) {
                if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                    return

                var bowlMovable = false

                for (i in 9..36) {
                    val itemStack = mc.thePlayer.inventoryContainer.getSlot(i).stack

                    if (itemStack == null) {
                        bowlMovable = true
                        break
                    } else if (itemStack.item == Items.bowl && itemStack.stackSize < 64) {
                        bowlMovable = true
                        break
                    }
                }

                if (bowlMovable) {
                    val openInventory = mc.currentScreen !is GuiInventory && simulateInventory.get()

                    if (openInventory)
                        mc.netHandler.addToSendQueue(C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT))
                    mc.playerController.windowClick(0, bowlInHotbar, 0, 1, mc.thePlayer)
                }
            }

            val soupInInventory = InventoryUtils.findItem(9, 36, Items.mushroom_stew)
            if (soupInInventory != -1 && InventoryUtils.hasSpaceHotbar()) {
                if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                    return

                val openInventory = mc.currentScreen !is GuiInventory && simulateInventory.get()
                if (openInventory)
                    mc.netHandler.addToSendQueue(C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT))

                mc.playerController.windowClick(0, soupInInventory, 0, 1, mc.thePlayer)

                if (openInventory)
                    mc.netHandler.addToSendQueue(C0DPacketCloseWindow())

                timer.reset()
            }
        }
    }
    @EventTarget
    fun onMotion(motionEvent: MotionEvent) {
        if (autoHealthValue.get() == "Pot" || autoHealthValue.get() == "All") {
            if (!timer.hasTimePassed(potDelayValue.get().toLong()) || mc.playerController.isInCreativeMode)
                return

            when (motionEvent.eventState) {
                EventState.PRE -> {
                    // Hotbar Potion
                    val potionInHotbar = findPotion(36, 45)

                    if (mc.thePlayer.health <= healthValue.get() && potionInHotbar != -1) {
                        if (mc.thePlayer.onGround) {
                            when (modeValue.get().toLowerCase()) {
                                "jump" -> mc.thePlayer.jump()
                                "port" -> mc.thePlayer.moveEntity(0.0, 0.42, 0.0)
                            }
                        }

                        // Prevent throwing potions into the void
                        val fallingPlayer = FallingPlayer(
                            mc.thePlayer.posX,
                            mc.thePlayer.posY,
                            mc.thePlayer.posZ,
                            mc.thePlayer.motionX,
                            mc.thePlayer.motionY,
                            mc.thePlayer.motionZ,
                            mc.thePlayer.rotationYaw,
                            mc.thePlayer.moveStrafing,
                            mc.thePlayer.moveForward
                        )

                        val collisionBlock = fallingPlayer.findCollision(20)?.pos

                        if (mc.thePlayer.posY - (collisionBlock?.y ?: 0) >= 2f)
                            return

                        potion = potionInHotbar
                        mc.netHandler.addToSendQueue(C09PacketHeldItemChange(potion - 36))

                        if (mc.thePlayer.rotationPitch <= 80F) {
                            RotationUtils.setTargetRotation(
                                Rotation(
                                    mc.thePlayer.rotationYaw,
                                    RandomUtils.nextFloat(80F, 90F)
                                )
                            )
                        }
                        return
                    }

                    // Inventory Potion -> Hotbar Potion
                    val potionInInventory = findPotion(9, 36)
                    if (potionInInventory != -1 && InventoryUtils.hasSpaceHotbar()) {
                        if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                            return

                        val openInventory = mc.currentScreen !is GuiInventory && simulateInventory.get()

                        if (openInventory)
                            mc.netHandler.addToSendQueue(
                                C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT)
                            )

                        mc.playerController.windowClick(0, potionInInventory, 0, 1, mc.thePlayer)

                        if (openInventory)
                            mc.netHandler.addToSendQueue(C0DPacketCloseWindow())

                        timer.reset()
                    }
                }
                EventState.POST -> {
                    if (potion >= 0 && RotationUtils.serverRotation.pitch >= 75F) {
                        val itemStack = mc.thePlayer.inventoryContainer.getSlot(potion).stack

                        if (itemStack != null) {
                            mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(itemStack))
                            mc.netHandler.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))

                            timer.reset()
                        }

                        potion = -1
                    }
                }
            }
        }
    }
    private fun findPotion(startSlot: Int, endSlot: Int): Int {
        for (i in startSlot until endSlot) {
            val stack = mc.thePlayer.inventoryContainer.getSlot(i).stack

            if (stack == null || stack.item !is ItemPotion || !ItemPotion.isSplash(stack.itemDamage))
                continue

            val itemPotion = stack.item as ItemPotion

            for (potionEffect in itemPotion.getEffects(stack))
                if (potionEffect.potionID == Potion.heal.id)
                    return i

            if (!mc.thePlayer.isPotionActive(Potion.regeneration))
                for (potionEffect in itemPotion.getEffects(stack))
                    if (potionEffect.potionID == Potion.regeneration.id) return i
        }

        return -1
    }

    override val tag: String?
        get() = healthValue.get().toString()

}