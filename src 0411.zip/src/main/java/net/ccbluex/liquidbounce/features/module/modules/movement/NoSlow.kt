/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.item.*
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
//import net.minecraft.network.play.server.S0BPacketAnimation
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

@ModuleInfo(name = "NoSlow", description = "Cancels slowness effects caused by soulsand and using items.",
    category = ModuleCategory.MOVEMENT)
class NoSlow : Module() {
    private val packetValue = ListValue("PacketMode", arrayOf("AntiCheat","Custom","Hypixel","Hypixel2","NCP","AAC","AAC5"), "AntiCheat")

    private val blockForwardMultiplier = FloatValue("BlockForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val blockStrafeMultiplier = FloatValue("BlockStrafeMultiplier", 1.0F, 0.2F, 1.0F)

    private val consumeForwardMultiplier = FloatValue("ConsumeForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val consumeStrafeMultiplier = FloatValue("ConsumeStrafeMultiplier", 1.0F, 0.2F, 1.0F)

    private val bowForwardMultiplier = FloatValue("BowForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val bowStrafeMultiplier = FloatValue("BowStrafeMultiplier", 1.0F, 0.2F, 1.0F)

    private val customOnGround = BoolValue("CustomOnGround", false)
    private val customDelayValue = IntegerValue("CustomDelay",60,10,200)

    private val packet = BoolValue("Packet", true)

    // Soulsand
    val soulsandValue = BoolValue("Soulsand", true)

    private fun sendPacket(event : MotionEvent, sendC07 : Boolean, sendC08 : Boolean, delay : Boolean, delayValue : Long, onGround : Boolean, watchDog : Boolean = false) {
        val digging = C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos(-1,-1,-1), EnumFacing.DOWN)
        val blockPlace = C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem())
        val blockMent = C08PacketPlayerBlockPlacement(BlockPos(-1, -1, -1), 255, mc.thePlayer.inventory.getCurrentItem(), 0f, 0f, 0f)
        if(onGround && !mc.thePlayer.onGround) {
            return
        }
//        if(!(packetValue.get().toLowerCase() == "hypixel" || !mc.thePlayer.isBlocking)) {
            if (sendC07 && event.eventState == EventState.PRE) {
                if (delay && MSTimer().hasTimePassed(delayValue)) {
                    mc.netHandler.addToSendQueue(digging)
                } else if (!delay) {
                    mc.netHandler.addToSendQueue(digging)
                }
            }
            if (sendC08 && event.eventState == EventState.POST) {
                if (delay && MSTimer().hasTimePassed(delayValue) && !watchDog) {
                    mc.netHandler.addToSendQueue(blockPlace)
                    MSTimer().reset()
                } else if (!delay && !watchDog) {
                    mc.netHandler.addToSendQueue(blockPlace)
                } else if (watchDog) {
                    mc.netHandler.addToSendQueue(blockMent)
                }
            }
//        }
    }

    @EventTarget
    fun onMotion(event: MotionEvent) {
        val heldItem = mc.thePlayer.heldItem
        if (heldItem == null || heldItem.item !is ItemSword || !MovementUtils.isMoving()) {
            return
        }
        val killAura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura
        val target = (LiquidBounce.moduleManager[KillAura::class.java] as KillAura).target
        if (!mc.thePlayer.isBlocking && !killAura.blockingStatus) {
            return
        }
        if(packetValue.get().toLowerCase() == "aac5"||(packetValue.get().toLowerCase() == "hypixel" && mc.thePlayer.isBlocking)) {
            if (event.eventState == EventState.POST && (mc.thePlayer.isUsingItem || mc.thePlayer.isBlocking() || killAura.blockingStatus)) {
                mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(BlockPos(-1, -1, -1), 255, mc.thePlayer.inventory.getCurrentItem(), 0f, 0f, 0f))
            }
            return
        }
        if (this.packet.get() && packetValue != null) {
            if (packetValue.get().toLowerCase() != "aac5" || packetValue.get().toLowerCase() != "hypixel" ) {
                if (!mc.thePlayer.isBlocking && !killAura.blockingStatus) {
                    return
                }
                when (packetValue.get().toLowerCase()) {
                    "anticheat" -> {
                        this.sendPacket(event, true, false, false, 0, false, false)
                        if (mc.thePlayer.ticksExisted % 2 == 0) {
                            this.sendPacket(event, false, true, false, 0, false)
                        }
//                if(mc.thePlayer.ticksExisted % 2 == 0) {
//                    sendPacket(event, true, false, false, 5, false, false)
//                } else {

//                    sendPacket(event, false, false, false, 5, false, false)
//                }
                    }

                    "aac" -> {
                        if (mc.thePlayer.ticksExisted % 3 == 0) {
                            sendPacket(event, true, false, false, 0, false)
                        } else {
                            sendPacket(event, false, true, false, 0, false)
                        }
                    }

                    "custom" -> {
                        sendPacket(event, true, true, true, customDelayValue.get().toLong(), customOnGround.get())
                    }

                    "ncp" -> {
                        sendPacket(event, true, true, false, 0, false)
                    }

                    "hypixel2" -> {
                        if (event.eventState == EventState.PRE) {
                            mc.netHandler.addToSendQueue(C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN))
                        } else {
                            mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(BlockPos(-1, -1, -1), 255, null, 0.0f, 0.0f, 0.0f))
                        }
                    }
                }

            }
        }
    }
    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val target = (LiquidBounce.moduleManager[KillAura::class.java] as KillAura).blockingStatus
        if(packetValue.get().toLowerCase() != "hypixel" || (mc.thePlayer.isBlocking || target)) {
            val heldItem = mc.thePlayer.heldItem?.item

            event.forward = getMultiplier(heldItem, true)
            event.strafe = getMultiplier(heldItem, false)
        }
    }

    private fun getMultiplier(item: Item?, isForward: Boolean) = when (item) {
        is ItemFood, is ItemPotion, is ItemBucketMilk -> {
            if (isForward) this.consumeForwardMultiplier.get() else this.consumeStrafeMultiplier.get()
        }
        is ItemSword -> {
            if (isForward) this.blockForwardMultiplier.get() else this.blockStrafeMultiplier.get()
        }
        is ItemBow -> {
            if (isForward) this.bowForwardMultiplier.get() else this.bowStrafeMultiplier.get()
        }
        else -> 0.2F
    }
    override val tag: String?
        get() = packetValue.get()

}

