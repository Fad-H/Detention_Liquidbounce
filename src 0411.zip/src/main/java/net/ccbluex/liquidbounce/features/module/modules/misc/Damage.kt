/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition

@ModuleInfo(name = "Damage", description = "Deals damage to yourself.", category = ModuleCategory.MISC, canEnable = false)
class Damage : Module() {

    private val modeValue = ListValue("Mode", arrayOf("NCP", "AAC"), "NCP")
    private val damageValue = IntegerValue("Damage", 1, 1, 20)

    override fun onEnable() {
        when (modeValue.get().toLowerCase()) {
            "ncp" -> {
                val x = mc.thePlayer.posX
                val y = mc.thePlayer.posY
                val z = mc.thePlayer.posZ

                repeat(65 * damageValue.get()) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.049, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y, z, false))
                }
                mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y, z, true))
            }
            "aac" -> mc.thePlayer.motionY = 5 * damageValue.get().toDouble()
        }
    }

}