/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.utils.timer;

public final class MSTimer {

    private static long newTime = -1;
    private long time = -1L;

    public boolean hasTimePassed(final long MS) {
        return System.currentTimeMillis() >= time + MS;
    }
    public static boolean javaHasTimePassed(final long MS) {
        return System.currentTimeMillis() >= newTime + MS;
    }

    public boolean dealy(final long MS) {
        return System.currentTimeMillis() >= MS;
    }

    public long hasTimeLeft(final long MS) {
        return (MS + time) - System.currentTimeMillis();
    }

    public void reset() {
        time = System.currentTimeMillis();
    }
    public static void JavaReset() {
        newTime = System.currentTimeMillis();
    }
}
