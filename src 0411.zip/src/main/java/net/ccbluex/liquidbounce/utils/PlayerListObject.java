package net.ccbluex.liquidbounce.utils;

public class PlayerListObject {
    public String name;

    public int kills;

    public PlayerListObject(String name, int kills) {
        this.name = name;
        this.kills = kills;
    }
}
